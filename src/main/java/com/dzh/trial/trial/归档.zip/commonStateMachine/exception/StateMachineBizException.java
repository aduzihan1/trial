package com.dzh.trial.trial.commonStateMachine.exception;

public class StateMachineBizException extends CommonStateMachineException {

    public StateMachineBizException(String message) {
        super(message);
    }

    public StateMachineBizException(Throwable e) {
        super(e);
    }

}
