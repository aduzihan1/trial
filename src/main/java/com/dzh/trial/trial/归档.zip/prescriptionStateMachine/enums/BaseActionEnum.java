package com.dzh.trial.trial.prescriptionStateMachine.enums;

public interface BaseActionEnum {

    String getBeanName();

}
