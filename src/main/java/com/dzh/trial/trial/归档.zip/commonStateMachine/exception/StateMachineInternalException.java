package com.dzh.trial.trial.commonStateMachine.exception;

public class StateMachineInternalException extends CommonStateMachineException {

    public StateMachineInternalException(String message) {
        super(message);
    }

}
