package com.dzh.trial.trial.commonStateMachine.core;

public interface StateMachineInfo {

    String getStateMachineFactoryBeanName();

    String getStateMachineId();

}
