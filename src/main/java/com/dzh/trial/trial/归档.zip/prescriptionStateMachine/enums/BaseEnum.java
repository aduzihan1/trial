package com.dzh.trial.trial.prescriptionStateMachine.enums;

public interface BaseEnum {

}
