package com.dzh.trial.trial.prescriptionStateMachine.entity;

import com.dzh.trial.trial.prescriptionStateMachine.enums.PrescriptionStateEnum;

import javax.validation.constraints.NotBlank;

public class Prescription {

    @NotBlank(message = "id不可为空")
    private String id;
    private PrescriptionStateEnum state;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public PrescriptionStateEnum getState() {
        return state;
    }

    public void setState(PrescriptionStateEnum state) {
        this.state = state;
    }

}
